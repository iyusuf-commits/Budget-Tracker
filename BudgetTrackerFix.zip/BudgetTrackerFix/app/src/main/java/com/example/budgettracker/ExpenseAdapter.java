package com.example.budgettracker;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.google.android.material.card.MaterialCardView;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ExpenseAdapter extends RecyclerView.Adapter<ExpenseAdapter.ExpenseViewHolder> {

    private final List<Expense> expenses;
    private final Activity activity;
    private final ActivityResultLauncher<Intent> editExpenseLauncher;
    private final OnExpenseActionListener onExpenseActionListener;

    // Selection mode fields
    private boolean isSelectionMode = false;
    private final List<Expense> selectedItems = new ArrayList<>();

    public interface OnExpenseActionListener {
        void onExpenseDeleted(Expense expense);
        void onExpenseDateChanged(Expense expense, long newDate);
        void onStartActionMode();
        void onSelectionChanged(int count);
    }

    public ExpenseAdapter(List<Expense> expenses, Activity activity, ActivityResultLauncher<Intent> editExpenseLauncher, OnExpenseActionListener onExpenseActionListener) {
        this.expenses = expenses;
        this.activity = activity;
        this.editExpenseLauncher = editExpenseLauncher;
        this.onExpenseActionListener = onExpenseActionListener;
    }

    @NonNull
    @Override
    public ExpenseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_expense, parent, false);
        return new ExpenseViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ExpenseViewHolder holder, int position) {
        Expense expense = expenses.get(position);
        holder.expenseNameText.setText(expense.getName());

        NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("in", "ID"));
        holder.expenseAmountText.setText(format.format(expense.getAmount()));

        holder.expenseCategoryText.setText(expense.getCategory());

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy", Locale.getDefault());
        holder.expenseDateText.setText(dateFormat.format(new Date(expense.getDate())));

        holder.cardView.setChecked(selectedItems.contains(expense));

        holder.itemView.setOnClickListener(v -> {
            if (isSelectionMode) {
                toggleSelection(expense, holder.cardView);
            } else {
                showOptionsDialog(expense, position);
            }
        });

        holder.itemView.setOnLongClickListener(v -> {
            if (!isSelectionMode) {
                isSelectionMode = true;
                onExpenseActionListener.onStartActionMode();
            }
            toggleSelection(expense, holder.cardView);
            return true;
        });
    }

    private void toggleSelection(Expense expense, MaterialCardView cardView) {
        if (selectedItems.contains(expense)) {
            selectedItems.remove(expense);
            cardView.setChecked(false);
        } else {
            selectedItems.add(expense);
            cardView.setChecked(true);
        }
        onExpenseActionListener.onSelectionChanged(selectedItems.size());

        if (selectedItems.isEmpty() && isSelectionMode) {
            isSelectionMode = false;
            // Let MainActivity know to finish the action mode.
            onExpenseActionListener.onSelectionChanged(0);
        }
    }

    public List<Expense> getSelectedItems() {
        return selectedItems;
    }

    public void clearSelection() {
        isSelectionMode = false;
        selectedItems.clear();
        notifyDataSetChanged();
    }

    private void showOptionsDialog(Expense expense, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle("Select Action")
                .setItems(new CharSequence[]{"Edit", "Change Date", "Delete"}, (dialog, which) -> {
                    switch (which) {
                        case 0: // Edit
                            Intent intent = new Intent(activity, EditExpenseActivity.class);
                            intent.putExtra("expense_to_edit", expense);
                            intent.putExtra("expense_position", position);
                            editExpenseLauncher.launch(intent);
                            break;
                        case 1: // Change Date
                            showDatePickerDialog(expense);
                            break;
                        case 2: // Delete
                            onExpenseActionListener.onExpenseDeleted(expense);
                            break;
                    }
                });
        builder.create().show();
    }

    private void showDatePickerDialog(Expense expense) {
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(expense.getDate());
        new DatePickerDialog(activity, (view, year, month, dayOfMonth) -> {
            Calendar newCal = Calendar.getInstance();
            newCal.set(year, month, dayOfMonth);
            onExpenseActionListener.onExpenseDateChanged(expense, newCal.getTimeInMillis());
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show();
    }


    @Override
    public int getItemCount() {
        return expenses.size();
    }

    static class ExpenseViewHolder extends RecyclerView.ViewHolder {
        MaterialCardView cardView;
        TextView expenseNameText;
        TextView expenseAmountText;
        TextView expenseCategoryText;
        TextView expenseDateText;

        public ExpenseViewHolder(@NonNull View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.card_view);
            expenseNameText = itemView.findViewById(R.id.expense_name_text);
            expenseAmountText = itemView.findViewById(R.id.expense_amount_text);
            expenseCategoryText = itemView.findViewById(R.id.expense_category_text);
            expenseDateText = itemView.findViewById(R.id.expense_date_text);
        }
    }
}