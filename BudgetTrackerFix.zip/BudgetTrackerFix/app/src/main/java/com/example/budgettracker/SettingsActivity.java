package com.example.budgettracker;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.google.android.material.button.MaterialButton;

import java.text.NumberFormat;
import java.util.Locale;

public class SettingsActivity extends AppCompatActivity {

    private RadioGroup themeRadioGroup;
    private RadioButton lightThemeRadioButton, darkThemeRadioButton, systemThemeRadioButton;
    private EditText weeklyLimitInput, monthlyLimitInput, yearlyLimitInput;
    private MaterialButton saveSettingsButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        themeRadioGroup = findViewById(R.id.theme_radio_group);
        lightThemeRadioButton = findViewById(R.id.light_theme_radio_button);
        darkThemeRadioButton = findViewById(R.id.dark_theme_radio_button);
        systemThemeRadioButton = findViewById(R.id.system_theme_radio_button);
        weeklyLimitInput = findViewById(R.id.weekly_limit_input);
        monthlyLimitInput = findViewById(R.id.monthly_limit_input);
        yearlyLimitInput = findViewById(R.id.yearly_limit_input);
        saveSettingsButton = findViewById(R.id.save_settings_button);

        addTextWatchers();
        loadSettings();

        saveSettingsButton.setOnClickListener(v -> {
            saveSettings();
            Toast.makeText(this, "Settings saved!", Toast.LENGTH_SHORT).show();

            // Relaunch MainActivity to apply theme
            Intent intent = new Intent(this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });
    }

    private void addTextWatchers() {
        weeklyLimitInput.addTextChangedListener(new NumberFormattingTextWatcher(weeklyLimitInput));
        monthlyLimitInput.addTextChangedListener(new NumberFormattingTextWatcher(monthlyLimitInput));
        yearlyLimitInput.addTextChangedListener(new NumberFormattingTextWatcher(yearlyLimitInput));
    }

    private void loadSettings() {
        SharedPreferences prefs = getSharedPreferences("prefs", MODE_PRIVATE);

        int theme = prefs.getInt("theme", AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
        if (theme == AppCompatDelegate.MODE_NIGHT_YES) {
            darkThemeRadioButton.setChecked(true);
        } else if (theme == AppCompatDelegate.MODE_NIGHT_NO) {
            lightThemeRadioButton.setChecked(true);
        } else {
            systemThemeRadioButton.setChecked(true);
        }

        NumberFormat formatter = NumberFormat.getNumberInstance(new Locale("in", "ID"));

        long weeklyLimit = prefs.getLong("weekly_limit", 0);
        long monthlyLimit = prefs.getLong("monthly_limit", 0);
        long yearlyLimit = prefs.getLong("yearly_limit", 0);

        if (weeklyLimit > 0) weeklyLimitInput.setText(formatter.format(weeklyLimit));
        if (monthlyLimit > 0) monthlyLimitInput.setText(formatter.format(monthlyLimit));
        if (yearlyLimit > 0) yearlyLimitInput.setText(formatter.format(yearlyLimit));
    }

    private void saveSettings() {
        SharedPreferences.Editor editor = getSharedPreferences("prefs", MODE_PRIVATE).edit();

        int selectedThemeId = themeRadioGroup.getCheckedRadioButtonId();
        int themeMode = AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM;
        if (selectedThemeId == R.id.dark_theme_radio_button) {
            themeMode = AppCompatDelegate.MODE_NIGHT_YES;
        } else if (selectedThemeId == R.id.light_theme_radio_button) {
            themeMode = AppCompatDelegate.MODE_NIGHT_NO;
        }

        AppCompatDelegate.setDefaultNightMode(themeMode);
        editor.putInt("theme", themeMode);

        String weeklyLimitStr = weeklyLimitInput.getText().toString().replaceAll("[Rp,.\\s]", "");
        String monthlyLimitStr = monthlyLimitInput.getText().toString().replaceAll("[Rp,.\\s]", "");
        String yearlyLimitStr = yearlyLimitInput.getText().toString().replaceAll("[Rp,.\\s]", "");

        editor.putLong("weekly_limit", weeklyLimitStr.isEmpty() ? 0 : Long.parseLong(weeklyLimitStr));
        editor.putLong("monthly_limit", monthlyLimitStr.isEmpty() ? 0 : Long.parseLong(monthlyLimitStr));
        editor.putLong("yearly_limit", yearlyLimitStr.isEmpty() ? 0 : Long.parseLong(yearlyLimitStr));

        editor.apply();
    }

    private static class NumberFormattingTextWatcher implements TextWatcher {
        private final EditText editText;
        private String current = "";

        NumberFormattingTextWatcher(EditText editText) {
            this.editText = editText;
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {}

        @Override
        public void afterTextChanged(Editable s) {
            if (!s.toString().equals(current)) {
                editText.removeTextChangedListener(this);

                String cleanString = s.toString().replaceAll("[Rp,.\\s]", "");

                if (!cleanString.isEmpty()) {
                    try {
                        double parsed = Double.parseDouble(cleanString);
                        NumberFormat formatter = NumberFormat.getNumberInstance(new Locale("in", "ID"));
                        String formatted = formatter.format(parsed);

                        current = formatted;
                        editText.setText(formatted);
                        editText.setSelection(formatted.length());
                    } catch (NumberFormatException e) {
                        // ignore
                    }
                }
                editText.addTextChangedListener(this);
            }
        }
    }
}