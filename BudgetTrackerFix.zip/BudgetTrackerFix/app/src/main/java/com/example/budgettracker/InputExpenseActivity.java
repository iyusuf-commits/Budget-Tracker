package com.example.budgettracker;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;

public class InputExpenseActivity extends AppCompatActivity {

    private EditText expenseNameInput;
    private EditText expenseAmountInput;
    private Spinner categorySpinner;
    private MaterialButton saveExpenseButton;
    private MaterialButton saveAndContinueButton;
    private ArrayList<Expense> newlyAddedExpenses = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input_expense);

        expenseNameInput = findViewById(R.id.expense_name_input);
        expenseAmountInput = findViewById(R.id.expense_amount_input);
        categorySpinner = findViewById(R.id.category_spinner);
        saveExpenseButton = findViewById(R.id.save_expense_button);
        saveAndContinueButton = findViewById(R.id.save_and_continue_button);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.expense_categories, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(adapter);

        expenseAmountInput.addTextChangedListener(new NumberFormattingTextWatcher(expenseAmountInput));

        saveExpenseButton.setOnClickListener(v -> handleSave(true));
        saveAndContinueButton.setOnClickListener(v -> handleSave(false));
    }

    private void handleSave(boolean finishAfterSave) {
        String expenseName = expenseNameInput.getText().toString().trim();
        String expenseAmountStr = expenseAmountInput.getText().toString().replaceAll("[Rp,.\\s]", "");

        if (finishAfterSave && expenseName.isEmpty() && expenseAmountStr.isEmpty()) {
            finish();
            return;
        }

        if (expenseName.isEmpty() || expenseAmountStr.isEmpty()) {
            Toast.makeText(this, "Please fill out all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        double expenseAmount = Double.parseDouble(expenseAmountStr);
        long currentDate = System.currentTimeMillis();
        String category = categorySpinner.getSelectedItem().toString();
        Expense newExpense = new Expense(expenseName, expenseAmount, currentDate, category);
        newlyAddedExpenses.add(newExpense);

        Toast.makeText(this, "Expense saved!", Toast.LENGTH_SHORT).show();

        if (finishAfterSave) {
            finish();
        } else {
            expenseNameInput.setText("");
            expenseAmountInput.setText("");
            expenseNameInput.requestFocus();
        }
    }

    @Override
    public void finish() {
        Intent resultIntent = new Intent();
        resultIntent.putExtra("new_expenses_list", newlyAddedExpenses);
        setResult(Activity.RESULT_OK, resultIntent);
        super.finish();
    }

    private static class NumberFormattingTextWatcher implements TextWatcher {
        private final EditText editText;
        private String current = "";

        NumberFormattingTextWatcher(EditText editText) {
            this.editText = editText;
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {}

        @Override
        public void afterTextChanged(Editable s) {
            if (!s.toString().equals(current)) {
                editText.removeTextChangedListener(this);
                String cleanString = s.toString().replaceAll("[Rp,.\\s]", "");
                if (!cleanString.isEmpty()) {
                    try {
                        double parsed = Double.parseDouble(cleanString);
                        NumberFormat formatter = NumberFormat.getNumberInstance(new Locale("in", "ID"));
                        String formatted = formatter.format(parsed);
                        current = formatted;
                        editText.setText(formatted);
                        editText.setSelection(formatted.length());
                    } catch (NumberFormatException e) {
                        // ignore
                    }
                }
                editText.addTextChangedListener(this);
            }
        }
    }
}