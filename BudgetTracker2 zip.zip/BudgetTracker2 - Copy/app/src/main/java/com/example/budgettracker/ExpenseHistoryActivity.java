package com.example.budgettracker;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButtonToggleGroup;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class ExpenseHistoryActivity extends AppCompatActivity {

    private RecyclerView expensesRecyclerView;
    private TextView noExpensesText;
    private MaterialButtonToggleGroup filterToggleGroup;
    private ArrayList<Expense> allExpenses;
    private ExpenseAdapter adapter;

    private final ActivityResultLauncher<Intent> editExpenseLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                    Expense updatedExpense = (Expense) result.getData().getSerializableExtra("updated_expense");
                    int position = result.getData().getIntExtra("expense_position", -1);

                    if (position != -1 && updatedExpense != null) {
                        allExpenses.set(position, updatedExpense);
                        filterExpenses(filterToggleGroup.getCheckedButtonId());

                        Intent resultIntent = new Intent();
                        resultIntent.putExtra("expenses_updated", true);
                        resultIntent.putExtra("expenses", allExpenses);
                        setResult(RESULT_OK, resultIntent);
                    }
                }
            });

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expense_history);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        expensesRecyclerView = findViewById(R.id.expenses_recycler_view);
        noExpensesText = findViewById(R.id.no_expenses_text);
        filterToggleGroup = findViewById(R.id.filter_toggle_group);

        allExpenses = (ArrayList<Expense>) getIntent().getSerializableExtra("expenses");

        filterToggleGroup.check(R.id.all_button);
        filterExpenses(R.id.all_button);

        filterToggleGroup.addOnButtonCheckedListener((group, checkedId, isChecked) -> {
            if (isChecked) {
                filterExpenses(checkedId);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.expense_history_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.action_reset) {
            showResetConfirmationDialog();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void showDeleteConfirmationDialog(Expense expense, int position) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Expense")
                .setMessage("Are you sure you want to delete this expense?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    allExpenses.remove(expense);
                    filterExpenses(filterToggleGroup.getCheckedButtonId());
                    Intent resultIntent = new Intent();
                    resultIntent.putExtra("expenses_updated", true);
                    resultIntent.putExtra("expenses", allExpenses);
                    setResult(RESULT_OK, resultIntent);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showResetConfirmationDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Reset Expenses")
                .setMessage("Are you sure you want to delete all expenses?")
                .setPositiveButton("Reset", (dialog, which) -> {
                    allExpenses.clear();
                    Intent resultIntent = new Intent();
                    resultIntent.putExtra("expenses_cleared", true);
                    setResult(RESULT_OK, resultIntent);
                    finish();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void filterExpenses(int checkedId) {
        List<Expense> filteredExpenses = new ArrayList<>();
        Calendar cal = Calendar.getInstance();

        if (checkedId == R.id.all_button) {
            filteredExpenses.addAll(allExpenses);
        } else {
            for (Expense expense : allExpenses) {
                Calendar expenseCal = Calendar.getInstance();
                expenseCal.setTimeInMillis(expense.getDate());

                if (checkedId == R.id.week_button) {
                    if (expenseCal.get(Calendar.WEEK_OF_YEAR) == cal.get(Calendar.WEEK_OF_YEAR) &&
                            expenseCal.get(Calendar.YEAR) == cal.get(Calendar.YEAR)) {
                        filteredExpenses.add(expense);
                    }
                } else if (checkedId == R.id.month_button) {
                    if (expenseCal.get(Calendar.MONTH) == cal.get(Calendar.MONTH) &&
                            expenseCal.get(Calendar.YEAR) == cal.get(Calendar.YEAR)) {
                        filteredExpenses.add(expense);
                    }
                } else if (checkedId == R.id.year_button) {
                    if (expenseCal.get(Calendar.YEAR) == cal.get(Calendar.YEAR)) {
                        filteredExpenses.add(expense);
                    }
                }
            }
        }

        if (filteredExpenses.isEmpty()) {
            noExpensesText.setVisibility(View.VISIBLE);
            expensesRecyclerView.setVisibility(View.GONE);
        } else {
            noExpensesText.setVisibility(View.GONE);
            expensesRecyclerView.setVisibility(View.VISIBLE);
            expensesRecyclerView.setLayoutManager(new LinearLayoutManager(this));
            adapter = new ExpenseAdapter(filteredExpenses, this, editExpenseLauncher, this::showDeleteConfirmationDialog);
            expensesRecyclerView.setAdapter(adapter);
        }
    }
}
