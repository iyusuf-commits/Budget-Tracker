package com.example.budgettracker;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ExpenseAdapter extends RecyclerView.Adapter<ExpenseAdapter.ExpenseViewHolder> {

    private List<Expense> expenses;
    private Activity activity;
    private ActivityResultLauncher<Intent> editExpenseLauncher;
    private OnDeleteClickListener onDeleteClickListener;

    public interface OnDeleteClickListener {
        void onDeleteClick(Expense expense, int position);
    }

    public ExpenseAdapter(List<Expense> expenses, Activity activity, ActivityResultLauncher<Intent> editExpenseLauncher, OnDeleteClickListener onDeleteClickListener) {
        this.expenses = expenses;
        this.activity = activity;
        this.editExpenseLauncher = editExpenseLauncher;
        this.onDeleteClickListener = onDeleteClickListener;
    }

    @NonNull
    @Override
    public ExpenseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_expense, parent, false);
        return new ExpenseViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ExpenseViewHolder holder, int position) {
        Expense expense = expenses.get(position);
        holder.expenseNameText.setText(expense.getName());

        NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("in", "ID"));
        holder.expenseAmountText.setText(format.format(expense.getAmount()));

        holder.expenseCategoryText.setText(expense.getCategory());

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy", Locale.getDefault());
        holder.expenseDateText.setText(dateFormat.format(new Date(expense.getDate())));

        holder.editExpenseButton.setOnClickListener(v -> {
            Intent intent = new Intent(activity, EditExpenseActivity.class);
            intent.putExtra("expense_to_edit", expense);
            intent.putExtra("expense_position", position);
            editExpenseLauncher.launch(intent);
        });

        holder.deleteExpenseButton.setOnClickListener(v -> {
            onDeleteClickListener.onDeleteClick(expense, position);
        });
    }

    @Override
    public int getItemCount() {
        return expenses.size();
    }

    static class ExpenseViewHolder extends RecyclerView.ViewHolder {
        TextView expenseNameText;
        TextView expenseAmountText;
        TextView expenseCategoryText;
        TextView expenseDateText;
        MaterialButton editExpenseButton;
        MaterialButton deleteExpenseButton;

        public ExpenseViewHolder(@NonNull View itemView) {
            super(itemView);
            expenseNameText = itemView.findViewById(R.id.expense_name_text);
            expenseAmountText = itemView.findViewById(R.id.expense_amount_text);
            expenseCategoryText = itemView.findViewById(R.id.expense_category_text);
            expenseDateText = itemView.findViewById(R.id.expense_date_text);
            editExpenseButton = itemView.findViewById(R.id.edit_expense_button);
            deleteExpenseButton = itemView.findViewById(R.id.delete_expense_button);
        }
    }
}