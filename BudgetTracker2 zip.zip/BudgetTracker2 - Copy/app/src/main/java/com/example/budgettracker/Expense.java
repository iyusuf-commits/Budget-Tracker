package com.example.budgettracker;

import java.io.Serializable;

public class Expense implements Serializable {
    private String name;
    private double amount;
    private long date;
    private String category;

    public Expense(String name, double amount, long date, String category) {
        this.name = name;
        this.amount = amount;
        this.date = date;
        this.category = category;
    }

    public String getName() {
        return name;
    }

    public double getAmount() {
        return amount;
    }

    public long getDate() {
        return date;
    }

    public String getCategory() {
        return category;
    }
}