package com.example.budgettracker;

import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private static final String CHANNEL_ID = "budget_tracker_channel";
    private static final int NOTIFICATION_ID = 1;
    private static final int PERMISSION_REQUEST_CODE = 101;

    private ArrayList<Expense> expenses = new ArrayList<>();
    private TextView totalExpensesText;
    private RecyclerView expensesRecyclerView;
    private ExpenseAdapter adapter;
    private PieChart pieChart;
    private MaterialButtonToggleGroup filterToggleGroup;

    private int currentTheme;

    private final ActivityResultLauncher<Intent> settingsLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                // Recreate activity to apply theme change
                recreate();
            });

    private final ActivityResultLauncher<Intent> addExpenseLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                    ArrayList<Expense> newExpenses = (ArrayList<Expense>) result.getData().getSerializableExtra("new_expenses_list");
                    if (newExpenses != null && !newExpenses.isEmpty()) {
                        expenses.addAll(newExpenses);
                        updateDashboard();
                        checkAllLimits();
                    }
                }
            });

    private final ActivityResultLauncher<Intent> editExpenseLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                    Expense updatedExpense = (Expense) result.getData().getSerializableExtra("updated_expense");
                    int position = result.getData().getIntExtra("expense_position", -1);

                    if (position != -1 && updatedExpense != null) {
                        // Since the list is filtered, we can't rely on the position directly.
                        // A real app would use a unique ID. For now, let's find the original object.
                        Expense originalExpense = findOriginalExpense(updatedExpense);
                        if (originalExpense != null) {
                            int originalIndex = expenses.indexOf(originalExpense);
                            if(originalIndex != -1) {
                                expenses.set(originalIndex, updatedExpense);
                            }
                        }
                        updateDashboard();
                        checkAllLimits();
                    }
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyTheme();
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        totalExpensesText = findViewById(R.id.total_expenses_text);
        pieChart = findViewById(R.id.pie_chart);
        expensesRecyclerView = findViewById(R.id.expenses_recycler_view);
        filterToggleGroup = findViewById(R.id.filter_toggle_group);
        FloatingActionButton addExpenseFab = findViewById(R.id.add_expense_fab);

        addExpenseFab.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, InputExpenseActivity.class);
            addExpenseLauncher.launch(intent);
        });

        filterToggleGroup.check(R.id.all_button);
        filterToggleGroup.addOnButtonCheckedListener((group, checkedId, isChecked) -> {
            if (isChecked) {
                updateDashboard();
            }
        });

        createNotificationChannel();
        requestNotificationPermission();
        setupPieChart();
        updateDashboard();
    }

    private void updateDashboard() {
        // Update total expenses TextView
        double totalExpenses = 0;
        for (Expense expense : expenses) {
            totalExpenses += expense.getAmount();
        }
        NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("in", "ID"));
        totalExpensesText.setText(format.format(totalExpenses));

        // Filter expenses based on the selected toggle
        int checkedId = filterToggleGroup.getCheckedButtonId();
        List<Expense> filteredExpenses = filterExpenses(checkedId);

        // Update RecyclerView
        expensesRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ExpenseAdapter(filteredExpenses, this, editExpenseLauncher, this::showDeleteConfirmationDialog);
        expensesRecyclerView.setAdapter(adapter);

        if (filteredExpenses.isEmpty()) {
            expensesRecyclerView.setVisibility(View.GONE);
            pieChart.setVisibility(View.GONE);
        } else {
            expensesRecyclerView.setVisibility(View.VISIBLE);
            pieChart.setVisibility(View.VISIBLE);
        }

        // Update Pie Chart with filtered expenses
        updatePieChart(filteredExpenses);
    }

    private List<Expense> filterExpenses(int checkedId) {
        if (checkedId == R.id.all_button) {
            return new ArrayList<>(expenses); // Return a copy
        }

        List<Expense> filteredList = new ArrayList<>();
        Calendar cal = Calendar.getInstance();

        for (Expense expense : expenses) {
            Calendar expenseCal = Calendar.getInstance();
            expenseCal.setTimeInMillis(expense.getDate());

            boolean inPeriod = false;
            if (checkedId == R.id.week_button) {
                inPeriod = expenseCal.get(Calendar.WEEK_OF_YEAR) == cal.get(Calendar.WEEK_OF_YEAR) &&
                        expenseCal.get(Calendar.YEAR) == cal.get(Calendar.YEAR);
            } else if (checkedId == R.id.month_button) {
                inPeriod = expenseCal.get(Calendar.MONTH) == cal.get(Calendar.MONTH) &&
                        expenseCal.get(Calendar.YEAR) == cal.get(Calendar.YEAR);
            } else if (checkedId == R.id.year_button) {
                inPeriod = expenseCal.get(Calendar.YEAR) == cal.get(Calendar.YEAR);
            }

            if (inPeriod) {
                filteredList.add(expense);
            }
        }
        return filteredList;
    }

    private void showDeleteConfirmationDialog(Expense expense, int position) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Expense")
                .setMessage("Are you sure you want to delete this expense?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    expenses.remove(expense);
                    updateDashboard();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private Expense findOriginalExpense(Expense expense) {
        // This is a workaround because we don't have unique IDs.
        for (Expense e : expenses) {
            if (e.getDate() == expense.getDate() && e.getName().equals(expense.getName())) {
                return e;
            }
        }
        return null;
    }

    private void setupPieChart() {
        pieChart.setUsePercentValues(true);
        pieChart.getDescription().setEnabled(false);
        pieChart.setExtraOffsets(5, 10, 5, 5);
        pieChart.setDragDecelerationFrictionCoef(0.95f);
        pieChart.setDrawHoleEnabled(true);

        int nightModeFlags = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        int textColor = (nightModeFlags == Configuration.UI_MODE_NIGHT_YES) ? Color.WHITE : Color.BLACK;
        pieChart.setHoleColor(Color.TRANSPARENT);
        pieChart.getLegend().setTextColor(textColor);
    }

    private void updatePieChart(List<Expense> expensesForChart) {
        Map<String, Float> categoryMap = new HashMap<>();
        for (Expense expense : expensesForChart) {
            String category = expense.getCategory();
            float amount = (float) expense.getAmount();
            categoryMap.merge(category, amount, Float::sum);
        }

        ArrayList<PieEntry> entries = new ArrayList<>();
        for (Map.Entry<String, Float> entry : categoryMap.entrySet()) {
            entries.add(new PieEntry(entry.getValue(), entry.getKey()));
        }

        if (entries.isEmpty()) {
            pieChart.setVisibility(View.GONE);
        } else {
            pieChart.setVisibility(View.VISIBLE);
            PieDataSet dataSet = new PieDataSet(entries, "");
            dataSet.setSliceSpace(3f);
            dataSet.setSelectionShift(5f);
            dataSet.setColors(ColorTemplate.MATERIAL_COLORS);

            PieData data = new PieData(dataSet);
            data.setValueTextSize(10f);

            int nightModeFlags = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
            int textColor = (nightModeFlags == Configuration.UI_MODE_NIGHT_YES) ? Color.WHITE : Color.BLACK;
            data.setValueTextColor(textColor);

            pieChart.setData(data);
            pieChart.invalidate();
        }
    }

    private void applyTheme() {
        SharedPreferences prefs = getSharedPreferences("prefs", MODE_PRIVATE);
        currentTheme = prefs.getInt("theme", AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
        AppCompatDelegate.setDefaultNightMode(currentTheme);
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateDashboard();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();
        if (itemId == R.id.action_settings) {
            Intent intent = new Intent(this, SettingsActivity.class);
            settingsLauncher.launch(intent);
            return true;
        } else if (itemId == R.id.action_reset_all) {
            showResetAllConfirmationDialog();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void showResetAllConfirmationDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Reset All Expenses")
                .setMessage("Are you sure you want to delete all expense history?")
                .setPositiveButton("Reset", (dialog, which) -> {
                    expenses.clear();
                    updateDashboard();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Budget Tracker Channel";
            String description = "Channel for expense limit notifications";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, PERMISSION_REQUEST_CODE);
            }
        }
    }

    private void checkAllLimits() {
        SharedPreferences prefs = getSharedPreferences("prefs", MODE_PRIVATE);
        checkExpenseLimit("weekly_limit", "weekly", prefs);
        checkExpenseLimit("monthly_limit", "monthly", prefs);
        checkExpenseLimit("yearly_limit", "yearly", prefs);
    }

    private void checkExpenseLimit(String limitKey, String period, SharedPreferences prefs) {
        long maxExpense = prefs.getLong(limitKey, 0);

        if (maxExpense > 0) {
            double total = 0;
            Calendar cal = Calendar.getInstance();

            for (Expense expense : expenses) {
                Calendar expenseCal = Calendar.getInstance();
                expenseCal.setTimeInMillis(expense.getDate());

                boolean inPeriod = false;
                switch (period) {
                    case "weekly":
                        inPeriod = expenseCal.get(Calendar.WEEK_OF_YEAR) == cal.get(Calendar.WEEK_OF_YEAR) &&
                                expenseCal.get(Calendar.YEAR) == cal.get(Calendar.YEAR);
                        break;
                    case "monthly":
                        inPeriod = expenseCal.get(Calendar.MONTH) == cal.get(Calendar.MONTH) &&
                                expenseCal.get(Calendar.YEAR) == cal.get(Calendar.YEAR);
                        break;
                    case "yearly":
                        inPeriod = expenseCal.get(Calendar.YEAR) == cal.get(Calendar.YEAR);
                        break;
                }

                if (inPeriod) {
                    total += expense.getAmount();
                }
            }

            if (total > maxExpense) {
                String message = "You have exceeded your " + period + " expense limit.";
                sendNotification(message);
                showWarning(message);
            }
        }
    }

    private void sendNotification(String message) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_settings) // Replace with a more suitable icon
                .setContentTitle("Expense Limit Exceeded")
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            notificationManager.notify(NOTIFICATION_ID, builder.build());
        }
    }

    private void showWarning(String message) {
        new AlertDialog.Builder(this)
                .setTitle("Expense Limit Warning")
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }
}
